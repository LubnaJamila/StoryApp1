import "../styles/styles.css";

import App from "./pages/app";
import AuthUtils from "./utils/auth-utils";

document.addEventListener("DOMContentLoaded", async () => {
  const app = new App({
    content: document.querySelector("#main-content"),
    drawerButton: document.querySelector("#drawer-button"),
    navigationDrawer: document.querySelector("#navigation-drawer"),
    navList: document.querySelector("#nav-list"),
  });

  if (
    !AuthUtils.isLoggedIn() &&
    window.location.hash !== "#/login" &&
    window.location.hash !== "#/register"
  ) {
    window.location.hash = "#/login";
  }

  await app.renderPage();

  window.addEventListener("hashchange", async () => {
    await app.renderPage();
  });
});
