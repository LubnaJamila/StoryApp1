import CONFIG from "../config";

class AddStoryModel {
  static ADD_STORY_ENDPOINT = `${CONFIG.BASE_URL}/stories`;

  async submitStory(formData, token) {
    const response = await fetch(AddStoryModel.ADD_STORY_ENDPOINT, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    });

    return await response.json();
  }
}

export default AddStoryModel;
